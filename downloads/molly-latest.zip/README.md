# Molly — Real-Time AI Video

## Quick Start

1. Make sure you have **Node.js** installed (https://nodejs.org)
2. Open a terminal in this folder
3. Run: `npm install`
4. Run: `npm start` (or double-click `start.bat`)
5. Enter your license key when prompted
6. Select your camera and you're live! 🎉

## Keyboard Shortcuts

| Key | Action |
|-----|--------|
| F2  | Toggle Picture-in-Picture |
| F3  | Toggle Detached Output Window |

## Support

If you have any issues, contact us with your license key.

© 2026 Molly
