@echo off
setlocal
cd /d "%~dp0"

echo =======================================
echo          Starting Molly...
echo =======================================
echo.

:: Check if Node.js is installed
where node >nul 2>&1
if %errorlevel% neq 0 (
    echo [!] Node.js not found. Installing Node.js automatically...
    echo     Please wait, this might take a minute or two.
    
    :: Download Node.js installer
    powershell -Command "Invoke-WebRequest -Uri 'https://nodejs.org/dist/v20.11.1/node-v20.11.1-x64.msi' -OutFile 'node_installer.msi'"
    
    :: Install silently
    echo     Running installer...
    msiexec /i node_installer.msi /quiet /qn /norestart

    :: Wait for it to be added to PATH in current session (refresh env)
    if exist "C:\Program Files\nodejs\node.exe" (
        set "PATH=%PATH%;C:\Program Files\nodejs"
    )

    :: Clean up installer
    del node_installer.msi >nul 2>&1
    
    echo     Node.js installed successfully!
    echo.
)

:: Auto-install dependencies if needed
if not exist "node_modules" (
    echo [*] First-time setup: Installing app dependencies...
    echo     This will only happen once.
    call npm install --production >nul 2>&1
    if %errorlevel% neq 0 (
        echo [X] Failed to install dependencies. Please check your internet.
        pause
        exit /b 1
    )
    echo     Dependencies installed successfully!
    echo.
)

:: Start Molly
echo [*] Launching Molly...
call npm start
